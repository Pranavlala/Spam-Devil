<p align="center">
  <img src="SpamX/RiZoeLX.png" alt="RiZoeLXSpam Logo">
</p>
<h1 align="center">
  <b>• SᴘᴀᴍX •</b>
</h1>

----

<h4> SpamX Is A Pyrogram Based Spam Bots For Telegram With Many Features </h4>
<br>
<h3 align="center"> Features °</h3>

- [x] Fast And Stable
- [x] Deploy Upto 20 Clients
- [x] Spam | pornspam | Dm Spam
- [x] Raid | Dm Riad
- [x] Profile Change cmds
- [x] Broadcast Cmd

----

<h3 align="center"> • Deployment • </h3>

<h4> Heroku Deployment </h4>

> The easy way to host this bot, deploy to Heroku 
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/RiZoeLX/SpamX)

<h4> Local Hosting </h4>

<i> First Fork The [Repo](https://github.com/RiZoeLX/SpamX) </i>
<br>
<i> Now Rename semple.env as .env And Fill Your Values </i>

<b> Terminal cmds -! </b>

- `git clone <your Forked repo>`
- `cd SpamX` #If You Changed Repo Name Then Use that Name
- `pip3 install -r requirements.txt`
- `python3 -m SpamX`

----

<h3 align="center"> String Session </h3>

> Click On Below Button To Expand 

<details>
<summary><b> Session </b></summary>
<br>
× <i> You'll need a API_ID & API_HASH in order to generate Pyrogram session string. Get This Values from https://my.telegram.org </i>
<h4>• Generate Session via Repl.it: </h4>    
<p><a href="https://replit.com/@RiZoeL/SpamX-Pryogram?v=1"><img src="https://img.shields.io/badge/Generate%20On%20Repl-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a></p>

</details>

----

<h3 align="center"> Support: </h3>

  * <i> Channel </i>: [@RiZoeLX](https://t.me/RiZoeLX) <br>
  * <i> Support </i>: [@DNHxHELL](https://t.me/DNHxHELL)

----

