# RiZoeL X - Telegram Projects
# (c) 2022 - 2023 RiZoeL
# Don't Kang Bitch -!



import asyncio
from pyrogram import idle
from . import (RiZoeL, RiZoeL2, RiZoeL3, RiZoeL4, RiZoeL5, 
                RiZoeL6, RiZoeL7, RiZoeL8, RiZoeL9, RiZoeL10, 
                RiZoeL11, RiZoeL12, RiZoeL13, RiZoeL14, RiZoeL15, 
                RiZoeL16, RiZoeL17, RiZoeL18, RiZoeL19, RiZoeL20, hl)

if RiZoeL:
    RiZoeL.start()
    RiZoeL.join_chat("RiZoeLX")
    RiZoeL.join_chat("DNHxHELL")
if RiZoeL2:
    RiZoeL2.start()
    RiZoeL2.join_chat("RiZoeLX")
    RiZoeL2.join_chat("DNHxHELL")
if RiZoeL3:
    RiZoeL3.start()
    RiZoeL3.join_chat("RiZoeLX")
    RiZoeL3.join_chat("DNHxHELL")
if RiZoeL4:
    RiZoeL4.start()
    RiZoeL4.join_chat("RiZoeLX")
    RiZoeL4.join_chat("DNHxHELL")
if RiZoeL5:
    RiZoeL5.start()
    RiZoeL5.join_chat("RiZoeLX")
    RiZoeL5.join_chat("DNHxHELL")
if RiZoeL6:
    RiZoeL6.start()
    RiZoeL6.join_chat("RiZoeLX")
    RiZoeL6.join_chat("DNHxHELL")
if RiZoeL7:
    RiZoeL7.start()
    RiZoeL7.join_chat("RiZoeLX")
    RiZoeL7.join_chat("DNHxHELL")
if RiZoeL8:
    RiZoeL8.start()
    RiZoeL8.join_chat("RiZoeLX")
    RiZoeL8.join_chat("DNHxHELL")
if RiZoeL9:
    RiZoeL9.start()
    RiZoeL9.join_chat("RiZoeLX")
    RiZoeL9.join_chat("DNHxHELL")
if RiZoeL10:
    RiZoeL10.start()
    RiZoeL10.join_chat("RiZoeLX")
    RiZoeL10.join_chat("DNHxHELL")
if RiZoeL11:
    RiZoeL11.start()
    RiZoeL11.join_chat("RiZoeLX")
    RiZoeL11.join_chat("DNHxHELL")
if RiZoeL12:
    RiZoeL12.start()
    RiZoeL12.join_chat("RiZoeLX")
    RiZoeL12.join_chat("DNHxHELL")
if RiZoeL13:
    RiZoeL13.start()
    RiZoeL13.join_chat("RiZoeLX")
    RiZoeL13.join_chat("DNHxHELL")
if RiZoeL14:
    RiZoeL14.start()
    RiZoeL14.join_chat("RiZoeLX")
    RiZoeL14.join_chat("DNHxHELL")
if RiZoeL15:
    RiZoeL15.start()
    RiZoeL15.join_chat("RiZoeLX")
    RiZoeL15.join_chat("DNHxHELL")
if RiZoeL16:
    RiZoeL16.start()
    RiZoeL16.join_chat("RiZoeLX")
    RiZoeL16.join_chat("DNHxHELL")
if RiZoeL17:
    RiZoeL17.start()
    RiZoeL17.join_chat("RiZoeLX")
    RiZoeL7.join_chat("DNHxHELL")
if RiZoeL18:
    RiZoeL18.start()
    RiZoeL18.join_chat("RiZoeLX")
    RiZoeL18.join_chat("DNHxHELL")
if RiZoeL19:
    RiZoeL19.start()
    RiZoeL19.join_chat("RiZoeLX")
    RiZoeL19.join_chat("DNHxHELL")
if RiZoeL20:
    RiZoeL20.start()
    RiZoeL20.join_chat("RiZoeLX")
    RiZoeL20.join_chat("DNHxHELL")

print("Your Spam Bots Successfully Deployed ✅")
print("Visit -! @RiZoeLX")

idle()
